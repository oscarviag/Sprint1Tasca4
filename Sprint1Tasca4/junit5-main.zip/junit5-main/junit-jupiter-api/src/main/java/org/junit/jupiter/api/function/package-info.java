/**
 * Functional interfaces used within JUnit Jupiter.
 */

package org.junit.jupiter.api.function;
