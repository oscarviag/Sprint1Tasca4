plugins {
    eclipse
    idea
    id("java-toolchain-conventions")
    id("spotless-conventions")
}
